/**
 * @fenero/lux-core — Veritas SDK primitives.
 *
 * Includes: generated OpenAPI types, auth provider abstraction,
 * VeritasClient (HTTP), runtime singleton (initLux/getDefaultClient),
 * VeritasSession (tenant + SSE), and CaseSseTransport.
 *
 * Product-specific layers (Gunnr, etc.) live in consumer apps, not here.
 */
export type { paths, components, operations } from "./generated.js";
export * from "./auth.js";
export { createVeritasClient, VeritasClient, APIError, resolveApiPath } from "./client.js";
export type { VeritasClientConfig, ClientHooks } from "./client.js";
export {
	initLux,
	getDefaultClient,
	getAuthProvider,
	isLuxInitialized,
	getLuxToken,
	type LuxInitConfig,
} from "./runtime.js";
export { CaseSseTransport } from "./events.js";
export type {
	CaseSseTransportOptions,
	CaseSseMessageHandler,
	StreamStatus,
} from "./events.js";
export { VeritasSession } from "./session.js";
